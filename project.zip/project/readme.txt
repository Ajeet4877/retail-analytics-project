README - Retail Sales Dashboard Project
=======================================

Project Overview:
-----------------
This project involves analyzing retail sales data to uncover insights about profit distribution, sales trends, and correlations between metrics.

Included Files:
---------------
1. retail_analysis_report.pdf - A 2-page analytical summary report.
2. dashboard_images.pdf - Visualizations including profit breakdown, sales trends, and correlations.
3. README.txt - This README file.

Key Visualizations:
-------------------
- Total Profit by Category
- Total Profit by Sub-Category
- Monthly Sales Trend
- Correlation Heatmap

Tools Used:
-----------
- Python (Pandas, Matplotlib, Seaborn)
- Jupyter Notebook

Instructions:
-------------
1. Review the report for insights and recommendations.
2. Use the dashboard PDF for a quick overview of key trends.
3. Refer to the Jupyter Notebook for code and further exploration.

Author:
-------
Ajeet Singh
Data Analyst Intern
